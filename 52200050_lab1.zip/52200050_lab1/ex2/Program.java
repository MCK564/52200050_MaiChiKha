import vn.edu.tdtu.*;
public class Program {
    public static void main(String[] args) {
        int[] a= {2,4,6,8,10};
        int[] b= {1,3,5,7,9};
        
        ArrayOutput ao = new ArrayOutput();
        ArrayHandler ah = new ArrayHandler();

        //Print these two arrays to console (using the print() method in the ArrayOutput class)
        ao.print(a);
        ao.print(b);

        //Merge these two arrays and assign the result to array c then print array c to the console
        int[] c = ah.merge(a, b);
        ao.print(c);

        //Sort the array c in ascending order then print the result to the console
        ah.sort(c);
        ao.print(c);

        //Write the contents of the array c to the file output.txt
        ao.write(c, "output.txt");
    }
}
