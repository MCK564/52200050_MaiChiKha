import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Program{
    private static boolean isOperator(Character c){
        List<Character> listOperators = Arrays.asList('+', '-', 'x', '/', '^');
        return listOperators.contains(c);
    }
    public static void main(String[] args) throws Exception {
        if(args.length>0){
            if(args[1]==null){
                System.out.println("Invalid expression");
                return;
            }
            else{
                char[] c = args[1].toCharArray();
                if(!isOperator(c[0])){
                    System.out.println("Unsupported operator");
                    return;
                }
                else{
                    double arg1 = Double.parseDouble(args[0]);
                    double arg2 = Double.parseDouble(args[2]);
                    if(c[0]=='+'){
                        System.out.println(arg1+arg2);
                    }
                    else if(c[0]=='-'){
                        System.out.println(arg1-arg2);
                    }
                    else if(c[0]=='x'){
                        System.out.println(arg1*arg2);
                    }
                    else if(c[0]=='/'){
                        if(arg2==0){
                            System.out.println("Error: Divide by zero");
                            return;
                        }
                        System.out.println(arg1/arg2);
                    }
                    else if(c[0]=='^'){
                        System.out.println(Math.pow(arg1,arg2));
                    }
                }
            }
            
        }
    }
}